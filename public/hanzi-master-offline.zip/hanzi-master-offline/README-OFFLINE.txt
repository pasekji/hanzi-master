HANZI MASTER - OFFLINE COPY

1. Extract the whole ZIP archive.
2. Keep index.html, app.js, and the vendor folder together.
3. Open index.html in Chrome, Edge, or Firefox.

The app does not need an internet connection or external API.
Learning progress stays in the browser storage on this device.
